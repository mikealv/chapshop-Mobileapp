
import React, { Component } from "react";
import { SafeAreaView, Text, View, TouchableOpacity, Image } from "react-native";
import { FlatList, ScrollView } from "react-native-gesture-handler";
import { APP_FONTS, APP_IMAGES, APP_URLS } from "../../utils/Common";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { heightPercentageToDP as hp, widthPercentageToDP as wp } from "react-native-responsive-screen";




// const shoppingBag = [
//     {
//         id: 1,
//         // profileImage: require('../../../assets/images/profile-img.png'),
//         productName: 'Chic Fuchsia',
//         // rating: 4.1,
//         price: '$20.00',
//         delivery: ' 31 Aug,2021',
//         imageUpload: require('../../../assets/images/product-img.png'),
//         size: '-M',
//         quantity: 1,
//         comment: 'Love the color and fit of the top.The delivery was quick.Thank you CHapShop'

//     },
//     {
//         id: 2,
//         // profileImage: require('../../../assets/images/profile-img.png'),
//         productName: 'Chic Fuchsia ',
//         // rating: 4.1,
//         price: '$20.00',
//         delivery: '31 Aug,2021',
//         imageUpload: require('../../../assets/images/product-img.png'),
//         size: '-M',
//         quantity: 1,
//         comment: 'Love the color and fit of the top.The delivery was quick.Thank you CHapShop'

//     }
//     // {
//     //     id: 3,
//     //     // profileImage: require('../../../assets/images/profile-img.png'),
//     //     productName: 'Chic Fuchsia ',
//     //     // rating: 4.1,
//     //     price: '$20.00',
//     //     delivery: '31 Aug,2021',
//     //     imageUpload: require('../../../assets/images/product-img.png'),
//     //     size: '-M',
//     //     quantity: 1,
//     //     comment: 'Love the color and fit of the top.The delivery was quick.Thank you CHapShop'

//     // },
// ]

const deliveryAddress = [
    {
        id: 1,
        customerName: 'Jennifer Smith',
        mobileNumber: '+1-9876543210',
        deliveryAddress: "Flat No -242,River View Apartment,2nd Street Sacramento,California-Pin Code -XXXXX",

    },
    {
        id: 2,
        // profileImage: require('../../../assets/images/profile-img.png'),
        customerName: 'Palak Sharma',
        // rating: 4.1,
        mobileNumber: '+1-705703302',
        deliveryAddress: "E1 -402,Sacramento,California-Pin Code -208002",

    }
]



class paymentSummary extends Component {

    constructor(props) {
        super(props)
        this.state = {
            token: '',
            // addressPage: false/
            addressPage: false,
            shoppingBag: '',
            paymentPage: false,
            bagPage: true,
            showSummaryPage: false,
            shoppingBagCartData: this.props.route.params.dataSend,
            totalPrice: this.props.route.params.priceTotal,
            shoppingCartData: this.props.route.params.dataSend,
            nameAdress: this.props.route.params.addressName,
            houseNumber: this.props.route.params.addressHouseNo,
            city: this.props.route.params.addressCity,
            area: this.props.route.params.addressArea,
            mobileNumber: this.props.route.params.mobileNo
        }
    }

    componentDidMount() {
        this.userDetail()
        console.log(this.state.shoppingBagCartData, 'dhdhdjshs')

    }

    async userDetail() {
        let userS = await AsyncStorage.getItem('@userToken')
        console.log(userS, 'userssss')
        this.setState({
            token: userS
        }, () => { this.state.token, 'token--->' })
        console.log(this.state.token, 'oojojtkt')
        this.getShoppingBag()




        //   this.wishlist()
        // await AsyncStorage.getItem('@user',JSON.stringify(user)).then(() => {
        //     console.log(user, 'fcmtokenLoginß')

        // })
    }

    placeOrderToAddress() {
        this.setState({
            showSummaryPage: true
        })
    }

    async getShoppingBag() {
        console.log('UWQ')
        let body = {

        }
        try {
            let response = await fetch(

                APP_URLS.getShoppingBag,
                {
                    'method': 'POST',
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'Authorization': "Bearer" + " " + this.state.token.split('"').join(''),

                    },
                    body: body
                }
            );
            if (response.status == 200) {


                response.json().then(data => {
                    console.log(data.products, 'fdaatat')

                    // if (data.response.status.statusCode === 200) {
                    if (data.status == 1) {
                        this.setState({
                            shoppingBag: data.products,
                            totalPrice: data.totalPrice
                        })
                        this.getOrderSummary()



                    }

                    else {
                        this.setState({ isLoading: false }, () => {
                        })
                    }

                });
            } else {

                this.setState({ isLoading: false }, () => {
                    alert('Something went wrong error code: fdfdf' + response.status)
                })
            }

        }
        catch (error) {

            this.setState({ isLoading: false }, () => {
                alert('Something went wrong error code: ' + error)
            })
        }


    }


    render() {
        return (
            <SafeAreaView style={{ flex: 1 }}>
                <View style={{ flex: 0.12, flexDirection: 'row', justifyContent: 'space-between', top: 0 }}>
                    <View style={{ flexDirection: 'row', padding: 10 }}>
                        <TouchableOpacity onPress={() => this.props.navigation.goBack()}>
                            <View>
                                <Image style={{ top: 0, left: 8, height: 20, width: 20, tintColor: 'black' }}
                                    resizeMode="contain"
                                    source={APP_IMAGES.arrowLeft} />

                            </View>
                        </TouchableOpacity>
                        <Text style={{ left: 40, fontFamily: APP_FONTS.bold }}>PAYMENT</Text>
                    </View>
                    <View style={{ flex: 0, backgroundColor: '#fffff', right: 100, flexDirection: 'row', justifyContent: 'space-between', top: 50 }}>
                        <View style={{ flexDirection: 'row' }}>
                            {/* <TouchableOpacity style={{flexDirection:'row'}} onPress={() => { this.setState({
                            addressPage:false
                        })}}> */}
                            <View style={{ height: 24, width: 24, borderRadius: 12 }}>
                                {/* <Text style={{ alignSelf: 'center', color: '#7bc0f7' }}>1</Text> */}
                                <Image source={APP_IMAGES.blueTick} style={{ height: 22, width: 22 }} />

                            </View>

                            <View style={{ left: 5, top: 2 }}>
                                <Text style={{ color: '#7bc0f7' }}>Bag-----</Text>
                            </View>
                            {/* </TouchableOpacity> */}
                        </View>
                        <View style={{ flexDirection: 'row' }}>
                            <View style={{ height: 24, width: 24, borderRadius: 12, }}>
                                {/* <Text style={{ alignSelf: 'center' }}>2</Text> */}
                                <Image source={APP_IMAGES.blueTick} style={{ height: 23, width: 23, right: 1, bottom: 1 }} />

                            </View>
                            {/* <TouchableOpacity onPress={() => { this.placeOrderToAddress()}}> */}
                            <View style={{ left: 5, top: 2 }}>
                                <Text style={{ color: '#9f9f9f' }}>Address---</Text>
                            </View>
                            {/* </TouchableOpacity> */}
                        </View>
                        <View style={{ flexDirection: 'row' }}>
                            <View style={{ borderColor: '#9f9f9f', height: 24, width: 24, borderRadius: 12, borderWidth: 1.5 ,left:2}}>
                                {
                                    this.state.showSummaryPage == true ?
                                        <Image source={APP_IMAGES.blueTick} style={{ height: 23, width: 23, right: 1, bottom: 1,left:3 }} />
                                        :
                                        <Text style={{ alignSelf: 'center' }}>3</Text>
                                }
                            </View>
                            <View style={{ left: 5, top: 2 }}>
                                <Text style={{ color: '#9f9f9f' }}>Payment---</Text>
                            </View>
                        </View>
                        <View style={{ flexDirection: 'row' }}>
                            <View style={{ borderColor: '#9f9f9f', height: 24, width: 24, borderRadius: 12, borderWidth: 1.5,left:5}}>
                                <Text style={{ alignSelf: 'center' }}>4</Text>
                            </View>
                            <View style={{ left: 6, top: 2 }}>
                                <Text style={{ color: '#9f9f9f' }}>Summary</Text>
                            </View>
                        </View>
                    </View>
                </View>
                <View style={{ borderColor: '#f0f0f0', borderBottomWidth: 2, height: 12 }} />

                {
                    this.state.showSummaryPage == true ?
                        //  <View style={{flex:1}}>

                        <View style={{ flex: 1, backgroundColor: '#f8f8f8' }}>
                            <ScrollView style={{ flex: 1 }}>
                                {/* <View style={{ backgroundColor: 'white', flex: 0.10, top: 10 ,height:hp('5%')}}>
                                <View style={{ padding: 0, flexDirection: 'row', justifyContent: 'space-between' }}>
                                    <Text style={{ color: '#3e3e3e', top: 12, left: 12 }}>Order number</Text>
                                    <Text style={{ color: '#3e3e3e', top: 12, right: 12, fontFamily: APP_FONTS.bold, fontSize: 12 }}>1027465833</Text>
                                </View>
                                <View />

                            </View> */}
                                <View style={{ backgroundColor: 'white', flex: 0.20, top: 20, height: hp('7%') }}>
                                    <View style={{ padding: 0, flexDirection: 'row' }}>
                                        <Image source={APP_IMAGES.cash} style={{ height: 20, width: 20, top: 15, left: 10 }} resizeMode={'contain'} />
                                        <Text style={{ color: '#3e3e3e', top: 14, left: 20, fontFamily: APP_FONTS.semi_bold, fontSize: 12, right: 0 }}>Estimated Delivery by Friday,Sep 10,2021</Text>
                                    </View>
                                    <View />

                                </View>
                                 <View style={{flex:1}}>
                                    <FlatList
                                        data={this.state.shoppingBagCartData}
                                        style={{ flex: 1, top: 10 }}
                                        keyExtractor={item => item.id}
                                        showsHorizontalScrollIndicator={false}
                                        renderItem={({ item, index, separator }) => {
                                            console.log(item, 'itEM-DARR--===')
                                            return (
                                                 <View style={{ flex: 0.80 }}>
                                                    <View style={{ backgroundColor: '#f0f0f0', padding: 20 }}>
                                                        <View style={{ backgroundColor: 'white', padding: 20 }}>
                                                        <Text style={{ padding: 10, color: '#bdbdbd', fontFamily: APP_FONTS.bold, fontSize: 12,left:70,bottom:10 }}>Commission {item.productId.commission}</Text>
                                                             <View style={{ backgroundColor: 'white', flexDirection: 'row' }}>
                                                                <Image source={{ uri: item.productId.images }} style={{ height: 70, width: 70 ,bottom:20}} />
                                                                <Text style={{ padding: 10, color: 'black', fontFamily: APP_FONTS.medium, fontSize: 12,bottom:20 }}>{item.productId.productName}</Text>
                                                            </View>
                                                            <View style={{ alignSelf: 'center', right: 30, bottom: 34, backgroundColor: 'white' }}>
                                                                <Text style={{ color: 'black', fontSize: 12, fontFamily: APP_FONTS.bold }}> FCFA{item.productId.mrp}</Text>
                                                                <View style={{ flexDirection: 'row', top: 3, backgroundColor: 'white' }}>
                                                                    <Text style={{ fontSize: 12, fontFamily: APP_FONTS.medium }}>Size {item.size}</Text>
                                                                    <View style={{
                                                                        flexDirection: 'row', height: '76%', width: 1.5, top: 3, left: 5,
                                                                        backgroundColor: '#909090'
                                                                    }} />
                                                                    <Text style={{ left: 10, fontSize: 12, fontFamily: APP_FONTS.medium }}>Qty{item.quantity}</Text>
                                                                </View>
                                                            </View>
                                                        </View>

                                                    </View>


                                                </View>
                                            )
                                        }}

                                    />
                                </View> 
                                {/* <View style={{ backgroundColor: 'white', padding: 20 }}>
                                     <View style={{ backgroundColor: 'white', flexDirection: 'row' }}>
                                         <Text style={{ padding: 10, color: 'black', fontFamily: APP_FONTS.bold, fontSize: 12 }}></Text>
                                    </View>
                                    <View style={{ alignSelf: 'center', right: 30, bottom: 24, backgroundColor: 'white' }}>
                                        <Text style={{ color: '#f53d9c', fontSize: 12, fontFamily: APP_FONTS.bold }}></Text>
                                        <View style={{ flexDirection: 'row', top: 3, backgroundColor: 'white' }}>
                                            <Text style={{ fontSize: 12, fontFamily: APP_FONTS.medium }}>Size </Text>
                                            <View style={{
                                                flexDirection: 'row', height: '76%', width: 1.5, top: 3, left: 5,
                                                backgroundColor: '#909090'
                                            }} />
                                            <Text style={{ left: 10, fontSize: 12, fontFamily: APP_FONTS.medium }}>Qty </Text>
                                        </View>
                                    </View>
                                </View> */}
                                {/* <View style={{ flex: 0.30, backgroundColor: 'white', top: 20, padding: 10, height: hp('20%') }}>
                                    {/* <View style={{ height: hp('15%'), top: 10 }}> */}

                                {/* <View style={{ flexDirection: 'row', justifyContent: 'space-between', backgroundColor: '#f8f8f8' }}> */}
                                {/* <Text style={{ fontSize: 12, fontFamily: APP_FONTS.bold, color: 'black', left: 10, top: 25 }}>{this.state.nameAdress}</Text> */}


                                {/* <Image source={APP_IMAGES.check} style={{ height: 16, width: 16, top: 18, right: 10 }} /> */}

                                {/* </View> */}
                                {/* <Text style={{ fontSize: 12, fontFamily: APP_FONTS.semi_bold, color: '#acacac', left: 10, top: 30 }}>{this.state.houseNumber} {this.state.city}  {this.state.area} </Text> */}
                                {/* <Text style={{ fontSize: 12 }}>{"address": {"area": "Ok", "city": "110033", "houseNo": "Hhh", "nearByLocation": "Sector2", "pinCode": 110033, "state": "Punjab"},}</Text> */}
                                {/* <Text style={{ fontSize: 12, fontFamily: APP_FONTS.bold, color: 'black', left: 10, top: 50 }}>Mobile: {this.state.mobileNumber}</Text> */}

                                {/* </View> */}

                                <View style={{ flex: 0.30, backgroundColor: 'white', top: 10, padding: 10, height: hp('20%') }}>
                                    {/* <View style={{ height: hp('15%'), top: 10 }}> */}

                                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', backgroundColor: '#f8f8f8' }}>
                                        <Text style={{ fontSize: 12, fontFamily: APP_FONTS.bold, color: 'black', left: 10, top: 25 }}>{this.state.nameAdress}</Text>


                                        {/* <Image source={APP_IMAGES.check} style={{ height: 16, width: 16, top: 18, right: 10 }} /> */}

                                    </View>
                                    <Text style={{ fontSize: 12, fontFamily: APP_FONTS.semi_bold, color: '#acacac', left: 10, top: 30 }}>{this.state.houseNumber} {this.state.city}  {this.state.area} </Text>
                                    {/* <Text style={{ fontSize: 12 }}>{"address": {"area": "Ok", "city": "110033", "houseNo": "Hhh", "nearByLocation": "Sector2", "pinCode": 110033, "state": "Punjab"},}</Text> */}
                                    <Text style={{ fontSize: 12, fontFamily: APP_FONTS.bold, color: 'black', left: 10, top: 50 }}>Mobile: {this.state.mobileNumber}</Text>

                                </View>

                                <View style={{ backgroundColor: 'white', flex: 0.20, top: 20, height: hp('15%') }}>
                                    <View style={{ padding: 20 }}>
                                        <Text style={{ color: '#3e3e3e', fontSize: 14, fontFamily: APP_FONTS.semi_bold }}>Payment Method</Text>
                                    </View>
                                    <View />
                                    <View style={{ padding: 10, left: 10, flexDirection: 'row', justifyContent: 'space-between' }}>
                                        <View style={{ flexDirection: 'row' }}>
                                            <Image source={APP_IMAGES.cash} style={{ height: 20, width: 20 }} resizeMode={'contain'} />
                                            <Text style={{ color: '#3e3e3e', left: 10, fontFamily: APP_FONTS.semi_bold }}>Cash on Delivery</Text>
                                        </View>
                                        <View style={{ right: 20 }}>
                                            <Image source={APP_IMAGES.greenTick} style={{ height: 20, width: 20 }} resizeMode={'contain'} />
                                        </View>
                                    </View>

                                </View>

                                <View style={{ backgroundColor: 'white', flex: 0.40, top: 10 }}>
                                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', padding: 12 }}>
                                        <Text style={{ fontFamily: APP_FONTS.bold, fontSize: 14, color: 'black' }} >Price Details</Text>
                                    </View>
                                    <View style={{ padding: 20 }}>
                                        <View style={{ flexDirection: 'row', justifyContent: 'space-between', bottom: 20 }}>
                                            <Text>Product Charges</Text>
                                            <Text>$20.00</Text>
                                        </View>
                                        <View style={{ flexDirection: 'row', justifyContent: 'space-between', bottom: 10 }}>
                                            <Text>Delivery Charges</Text>
                                            <Text>$20.00</Text>
                                        </View>
                                        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                                            <Text>Discount</Text>
                                            <Text>$20.00</Text>
                                        </View>
                                    </View>
                                </View>
                                <View style={{ flexDirection: 'row', justifyContent: 'space-between', padding: 10, borderColor: '#ededed', borderWidth: 1.5, top: 20, height: hp('10%') }}>
                                    <Text style={{ fontFamily: APP_FONTS.bold, fontSize: 14, color: 'black' }}>Order Total</Text>
                                    <Text style={{ fontFamily: APP_FONTS.bold, fontSize: 14, color: 'black' }}>FCFA {this.state.totalPrice}</Text>
                                </View>
                            </ScrollView>
                        </View>


                        :
                        <View style={{ flex: 1, backgroundColor: '#f8f8f8' }}>
                            <View style={{ backgroundColor: 'white', flex: 0.20, top: 20 }}>
                                <View style={{ padding: 20 }}>
                                    <Text style={{ color: '#3e3e3e', fontSize: 14, fontFamily: APP_FONTS.semi_bold }}>Payment Method</Text>
                                </View>
                                <View />
                                <View style={{ padding: 10, left: 10, flexDirection: 'row', justifyContent: 'space-between' }}>
                                    <View style={{ flexDirection: 'row' }}>
                                        <Image source={APP_IMAGES.cash} style={{ height: 20, width: 20 }} resizeMode={'contain'} />
                                        <Text style={{ color: '#3e3e3e', left: 10, fontFamily: APP_FONTS.semi_bold }}>Cash on Delivery</Text>
                                    </View>
                                    <View style={{ right: 20 }}>
                                        <Image source={APP_IMAGES.greenTick} style={{ height: 20, width: 20 }} resizeMode={'contain'} />
                                    </View>
                                </View>

                            </View>

                            <View style={{ backgroundColor: 'white', flex: 0.40, top: 40 }}>
                                <View style={{ flexDirection: 'row', justifyContent: 'space-between', padding: 12 }}>
                                    <Text style={{ fontFamily: APP_FONTS.bold, fontSize: 14, color: 'black' }} >Price Details</Text>
                                </View>
                                <View style={{ padding: 20 }}>
                                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', bottom: 20 }}>
                                        <Text>Product Charges</Text>
                                        <Text>$20.00</Text>
                                    </View>
                                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', bottom: 10 }}>
                                        <Text>Delivery Charges</Text>
                                        <Text>$20.00</Text>
                                    </View>
                                    <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                                        <Text>Discount</Text>
                                        <Text>$20.00</Text>
                                    </View>
                                </View>
                            </View>
                            <View style={{ flexDirection: 'row', justifyContent: 'space-between', padding: 10, borderColor: '#ededed', borderWidth: 1.5 }}>
                                <Text style={{ fontFamily: APP_FONTS.bold, fontSize: 14, color: 'black' }}>Order Total</Text>
                                <Text style={{ fontFamily: APP_FONTS.bold, fontSize: 14, color: 'black' }}>FCFA {this.state.totalPrice}</Text>
                            </View>

                        </View>

                }
                 
                <View style={{ flex: 0.10, flexDirection: 'row', justifyContent: 'space-between', bottom: 0, borderRadius: 1, borderColor: 'black', padding: 15 }}>

                    <View style={{ flexDirection: 'row', top: 10 }}>
                        <Text style={{ fontFamily: APP_FONTS.bold, color: 'black', fontSize: 14 }}>FCFA {this.state.totalPrice}</Text>
                    </View>
                    <View style={{ flexDirection: 'row', right: 20, width: 140, height: 46, backgroundColor: '#F43297', borderRadius: 8 }}>
                       
                       {
                           this.state.showSummaryPage == true?
                           <TouchableOpacity onPress={() => this.props.navigation.navigate('PlaceOrderPage')}>
                            <View style={{}}>
                                <Text style={{ fontFamily: APP_FONTS.bold, color: 'white', alignSelf: 'center', left: 30, top: 10 }}>Place Order</Text>

                            </View>
                        </TouchableOpacity>
                        :
                        <TouchableOpacity onPress={() => this.placeOrderToAddress()}>
                        <View style={{}}>
                            <Text style={{ fontFamily: APP_FONTS.bold, color: 'white', alignSelf: 'center', left: 30, top: 10 }}>Continue</Text>

                        </View>
                    </TouchableOpacity>

                       } 
                    </View>

                </View>













            </SafeAreaView>
        )
    }



}

export default paymentSummary;