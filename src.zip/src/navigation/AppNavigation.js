import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
// import Login from "../Screens/Login";
// import Hedge from "../Screens/Hedge";
// import Splash from "../Screens/Splash";
import login from "../screens/Login/login";
import otp from "../screens/Otp/otp";
import editProfile from "../screens/Account/editProfile";
import bottomDrawer from "../components/drawer/bottomDrawer"
import productList from "../screens/Categories/productList";
import productDetail from "../screens/Categories/productDetail";
import addTobag from "../screens/Categories/addTobag";

const Stack = createStackNavigator()

export default function AppNavigation(){
    return(
        <NavigationContainer theme={{colors:{background:'white'}}}>
            <Stack.Navigator initialRouteName="Login">
                
                <Stack.Screen name="Login"component={login} options={{headerShown:false}}/>
                <Stack.Screen name="Otp"component={otp} options={{headerShown:false}}/>
                <Stack.Screen name="bottomDrawer" component={bottomDrawer} options={{headerShown:false}}/>
                <Stack.Screen name="EditProfile" component={editProfile} options={{headerShown:false}}/>
                <Stack.Screen name="ProductList" component={productList} options={{headerShown:false}}/>
                <Stack.Screen name="ProductDetail" component={productDetail} options={{headerShown:false}}/>
                <Stack.Screen name="AddToBag" component={addTobag} options={{headerShown:false}}/>
               
              </Stack.Navigator>
        </NavigationContainer>
    )
}