import React, { Component } from "react";
import { Text, View, FlatList, Image, ScrollView, TouchableOpacity, Platform } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { APP_FONTS, APP_IMAGES, APP_URLS, CATEGORY_URLS } from "../../utils/Common";




const ProductList = [
    {
        _id: "625d5cdc518dce904e8953ab",
        // parentSubCategoryName: "Bottom wear",
        // childSubCategoryName: "All Tops",
        category: "625cf768191cf500d6ef8caa",
        productName: "Women Black & Pink Wrap",
        image: require('../../../assets/images/product-img.png'),
        price: '$20.00',
        commission: '$2 Commission',
        isActive: true,
        createdAt: "2022-04-18T12:43:08.498Z",
        updatedAt: "2022-04-18T12:43:08.498Z",
        __v: 0
    },
    {
        _id: "625d5cdc518dce904e8953ab",
        parentSubCategoryName: "Bottom wear",
        childSubCategoryName: "All Tops",
        category: "625cf768191cf500d6ef8caa",
        productName: "Women Black & Pink Wrap",
        image: require('../../../assets/images/product-img-two.png'),
        price: '$20.00',
        commission: '$2 Commission',
        isActive: true,
        createdAt: "2022-04-18T12:43:08.498Z",
        updatedAt: "2022-04-18T12:43:08.498Z",
        __v: 0
    },
    {
        _id: "625d5cdc518dce904e8953ab",
        parentSubCategoryName: "Bottom wear",
        childSubCategoryName: "All Tops",
        category: "625cf768191cf500d6ef8caa",
        productName: "Women Black & Pink Wrap",
        image: require('../../../assets/images/product-img-three.png'),
        price: '$20.00',
        commission: '$2 Commission',
        isActive: true,
        createdAt: "2022-04-18T12:43:08.498Z",
        updatedAt: "2022-04-18T12:43:08.498Z",
        __v: 0
    },
    {
        _id: "625d5cdc518dce904e8953ab",
        parentSubCategoryName: "Bottom wear",
        childSubCategoryName: "All Tops",
        category: "625cf768191cf500d6ef8caa",
        productName: "Women Black & Pink Wrap",
        image: require('../../../assets/images/product-img-four.png'),
        price: '$20.00',
        commission: '$2 Commission',
        isActive: true,
        createdAt: "2022-04-18T12:43:08.498Z",
        updatedAt: "2022-04-18T12:43:08.498Z",
        __v: 0
    },
    {
        _id: "625d5cdc518dce904e8953ab",
        parentSubCategoryName: "Bottom wear",
        childSubCategoryName: "All Tops",
        category: "625cf768191cf500d6ef8caa",
        productName: "Women Black & Pink Wrap",
        image: require('../../../assets/images/product-img.png'),
        price: '$20.00',
        commission: '$2 Commission',
        isActive: true,
        createdAt: "2022-04-18T12:43:08.498Z",
        updatedAt: "2022-04-18T12:43:08.498Z",
        __v: 0
    },
    {
        _id: "625d5cdc518dce904e8953ab",
        parentSubCategoryName: "Bottom wear",
        childSubCategoryName: "All Tops",
        category: "625cf768191cf500d6ef8caa",
        productName: "Women Black & Pink Wrap",
        image: require('../../../assets/images/product-img.png'),
        price: '$20.00',
        commission: '$2 Commission',
        isActive: true,
        createdAt: "2022-04-18T12:43:08.498Z",
        updatedAt: "2022-04-18T12:43:08.498Z",
        __v: 0
    },

]



class productList extends Component {

    constructor(props) {
        super(props)
        this.state = {
            mainCategory: '',

        }
    }







    componentDidMount() {
        // this.productList()
        // this.subCategory()
    }

    async getProduct() {
        let body = {
            subCategoryName: "625d5d0c518dce904e8953af"
        }
        console.log('shomoshahaah')
        try {
            let response = await fetch(

                APP_URLS.getProduct,
                {
                    'method': 'POST',
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(body)
                }
            );
            if (response.status == 200) {
                console.log('normal----->')

                response.json().then(data => {

                    console.log('product', JSON.stringify(data))
                    //console.log('convoeys', JSON.stringify(data.usersChatData[0].message))
                    // if (data.response.status.statusCode === 200) {
                    if (data.status === 1) {
                        // console.log(data.category, 'catteetete')
                        // this.setState({
                        //     mainCategory: data.category
                        // }, () => { this.state.mainCategory, 'mainCategoriiiess' })
                        // let token = data.response.userData.accessToken
                        // let user = data.response.userData
                        // userToken = token
                        // AsyncStorage.setItem('@user', JSON.stringify(user)).then(() => {
                        //     this.props.navigation.navigate('DrawerScreen')
                        //     this.setState({
                        //         isLoading:false
                        //     })
                        // })
                        //     this.props.navigation.navigate('Otp',{otpOutput:this.state.otpRecieved,
                        //         phoneNumber: this.state.phone,
                        //         countryCode: this.state.countryCode})
                        //     // alert('hahaah')
                    }
                    // else if (data.status === 0) {
                    //     alert(data.message)
                    // }
                    else {
                        this.setState({ isLoading: false }, () => {
                        })
                    }

                });
            } else {

                this.setState({ isLoading: false }, () => {
                    alert('Something went wrong error code: fdfdf' + response.status)
                })
            }

        }
        catch (error) {

            this.setState({ isLoading: false }, () => {
                alert('Something went wrong error code: ' + error)
            })
        }
    }


    // categories(){

    render() {
        return (
            <SafeAreaView style={{ flex: 1 }}>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', top: 10 }}>
                    <View style={{ flexDirection: 'row', left: 0 }}>
                        <TouchableOpacity onPress={() => this.props.navigation.goBack()}>
                            <View>
                                <Image style={{ top: 0, left: 8, height: 20, width: 20, tintColor: 'black' }}
                                    resizeMode="contain"
                                    source={APP_IMAGES.arrowLeft} />

                            </View>
                        </TouchableOpacity>
                        <Text style={{ left: 40, fontFamily: APP_FONTS.bold }}>TOPWEAR</Text>
                    </View>
                    {/* <View> */}
                    <View style={{ flexDirection: 'row' }}>
                        <Image source={APP_IMAGES.search} style={{ height: 20, width: 20, right: 30 }} resizeMode="contain" />
                        {/* </View> */}
                        {/* <View> */}
                        <Image source={APP_IMAGES.heart} style={{ height: 20, width: 20, right: 20 }} resizeMode="contain" />
                        {/* </View> */}
                        {/* <View> */}
                        <Image source={APP_IMAGES.cart} style={{ height: 20, width: 20, right: 10 }} resizeMode="contain" />
                    </View>

                </View>
                <View style={{
                    top: 20, flexDirection: 'row', height: 55, justifyContent: 'space-around', shadowColor: '#000',
                    shadowOffset: { width: 0, height: 20 },
                    shadowOpacity: Platform.OS == 'ios' ? 0 : 0.8,
                    shadowRadius: 0,
                    elevation: 1
                }}>
                    <View style={{ flexDirection: 'row', right: 10 }}>
                        <Text style={{ color: "#F43297", fontSize: 14, fontFamily: APP_FONTS.semi_bold, top: 5 }}>Sort</Text>
                        <Image source={APP_IMAGES.arrowDown} style={{ height: 12, width: 12, left: 5, top: 8 }} resizeMode="contain" />
                    </View>
                    <View style={{ flexDirection: 'row' }}>
                        <Text style={{ color: "#F43297", fontFamily: APP_FONTS.semi_bold, top: 5 }}>Size</Text>
                        <Image source={APP_IMAGES.arrowDown} style={{ height: 12, width: 12, top: 8, left: 5 }} resizeMode="contain" />
                    </View>
                    <View style={{ flexDirection: 'row' }}>
                        <Text style={{ color: "#F43297", fontFamily: APP_FONTS.semi_bold, top: 5 }}>Type</Text>
                        <Image source={APP_IMAGES.arrowDown} style={{ height: 12, width: 12, top: 8, left: 5 }} resizeMode="contain" />
                    </View>
                    {/* <View style={{borderColor:'black',borderWidth:1}} /> */}
                    <View style={{ flexDirection: 'row', left: 10 }}>
                        <View style={{ borderColor: '#ececec', borderWidth: 1, height: 25, top: 4, right: 10 }} />
                        <Text style={{ color: "#F43297", fontFamily: APP_FONTS.semi_bold, top: 5 }}>Filter</Text>
                        <Image source={APP_IMAGES.filter} style={{ height: 12, width: 12, top: 8, left: 5 }} resizeMode="contain" />
                    </View>
                </View>
                <View style={{ flex: 1, top: 0 ,backgroundColor:'red'}}>
                    <FlatList
                        // horizontal
                        data={ProductList}
                        style={{ flex: 1,backgroundColor:'white',padding:0}}
                        keyExtractor={item => item.id}
                        numColumns={2}
                        showsVerticalScrollIndicator={false}
                        // showsHorizontalScrollIndicator={false}
                        renderItem={({ item, index, separator }) => {
                            return (
                                <View style={{
                                     backgroundColor: '#ffffff',borderRadius: 5, height: 350, width:Platform.OS == 'ios'?179:'48%', marginLeft: 6, marginRight: 0, marginTop: 10, shadowColor: '#000',

                                    //  borderRadius: 5, height: 350, width:Platform.OS == 'ios'?179: 172, marginLeft: 6, marginRight: 0, marginTop: 10, shadowColor: '#000',
                                    shadowOffset: { width: 0, height: 2 },
                                    shadowOpacity: 0.5,
                                    shadowRadius: 2,
                                    elevation: 2,
                                }}>
                                    <TouchableOpacity onPress={() => {this.props.navigation.navigate('ProductDetail')}}>
                                        <Image source={item.image} style={{ height: 240, width: '100%' }} resizeMode='stretch' />
                                        <View style={{ backgroundColor: '#CECFD4', height: 25, width: 25, borderRadius: 12, zIndex: 100, bottom: 30, alignSelf: 'flex-end', right: 10 }}>
                                            <Image source={APP_IMAGES.heart} style={{ height: 14, width: 14, alignSelf: 'center', top: 6 }} resizeMode='contain' />
                                        </View>
                                        <Text style={{ fontSize: 11, color: 'black', alignSelf: 'center', fontFamily: APP_FONTS.bold, bottom: 10 }}>{item.productName}</Text>
                                        <View style={{ flexDirection: 'row', padding: 10, justifyContent: 'space-between', bottom: 8 }}>
                                            <Text style={{ color: "#F43297", fontSize: 12, fontFamily: APP_FONTS.bold }}>20.600FCFA</Text>
                                            <View style={{ flexDirection: 'row' }}>
                                                <Text style={{ fontSize: 10, fontFamily: APP_FONTS.bold, right: 3 }}>5000</Text>
                                                <Image source={APP_IMAGES.info} style={{ height: 15, width: 15 }} />
                                            </View>

                                        </View>
                                        <View style={{ flexDirection: 'row', flex: 1, bottom: 25 }}>
                                            <Image source={APP_IMAGES.whatsapp} style={{ height: 70, width: 70, right: 10 }} resizeMode="contain" />
                                            <Image source={APP_IMAGES.facebook} style={{ height: 70, width: 70, right: 40 }} resizeMode="contain" />
                                            <Image source={APP_IMAGES.instagram} style={{ height: 70, width: 70, right: 70 }} resizeMode="contain" />
                                            <Image source={APP_IMAGES.download} style={{ height: 70, width: 70, right: 100 }} resizeMode="contain" />
                                        </View>
                                    </TouchableOpacity>
                                    {/* <View style={{ width: '100%', height: 90, borderRadius: 0, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: 'red' }}>
                                            <Image source={APP_IMAGES.man} style={{ height: 20, width: 20, right: 0 }} resizeMode='contain' />
                                            <Text style={{ fontSize: 11, fontFamily: APP_FONTS.semi_bold, top: 10 }}>{item.categoryName}</Text>
                                         </View> */}
                                </View>
                            )
                        }}
                    />
                </View>

            </SafeAreaView>
        )
    }



}

export default productList;