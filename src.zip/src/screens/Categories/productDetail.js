
import React, { Component } from "react";
import { Text, View, TouchableOpacity, Image } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { APP_FONTS, APP_IMAGES } from "../../utils/Common";
import { SliderBox } from "react-native-image-slider-box";
import { FlatList, ScrollView } from "react-native-gesture-handler";
import { Rating } from 'react-native-ratings';




const ITEMS = [
    {
        id: 1,
        category: require('../../../assets/images/product-img.png'),
        name: 'Tops'
    },
    {
        id: 2,
        category: require('../../../assets/images/product-img.png'),
        name: 'Tshirts'
    },
    {
        id: 3,
        category: require('../../../assets/images/product-img.png'),
        name: 'Jackets',

    },
    {
        id: 4,
        category: require('../../../assets/images/product-img.png'),
        name: 'Jackets'
    },
    {
        id: 5,
        category: require('../../../assets/images/product-img.png'),
        name: 'Tops'
    },
    {
        id: 6,
        category: require('../../../assets/images/product-img.png'),
        name: 'Jackets'
    }
]

const REVIEWS = [
    {
        id: 1,
        profileImage: require('../../../assets/images/profile-img.png'),
        profileName: 'Palak Sharma',
        rating: 4.1,
        date: '25 Jul,2021',
        imageUpload: require('../../../assets/images/product-img.png'),
        remark: 'Very Good',
        comment: 'Love the color and fit of the top.The delivery was quick.Thank you CHapShop'
    },
    {
        id: 1,
        profileImage: require('../../../assets/images/profile-img.png'),
        profileName: 'Palak Sharma',
        rating: 4.1,
        date: '25 Jul,2021',
        remark: 'Very Good',
        imageUpload: require('../../../assets/images/product-img.png'),
        comment: 'Love the color and fit of the top.The delivery was quick.Thank you CHapShop'
    }

]

// handleRating(rate){
//    this.set
// }


class productDetail extends Component {

    constructor(props) {
        super(props)
        this.state = {
            images: [
                require('../../../assets/images/product-img-four.png'),
                require('../../../assets/images/product-img-three.png'),
                require('../../../assets/images/product-img-two.png'),
                require('../../../assets/images/product-img-four.png'),
                // require('./assets/images/girl.jpg'),          // Local image
            ]
        }
    }
    ratingCompleted(rating) {
        console.log("Rating is: " + rating)

    }

    render() {
        return (
            <SafeAreaView style={{ flex: 1 }}>

                <View style={{ flex: 0.08, flexDirection: 'row', justifyContent: 'space-between', top: 10 }}>
                    <View style={{ flexDirection: 'row', left: 0 }}>
                        <TouchableOpacity onPress={() => this.props.navigation.goBack()}>
                            <View>
                                <Image style={{ top: 0, left: 8, height: 20, width: 20, tintColor: 'black' }}
                                    resizeMode="contain"
                                    source={APP_IMAGES.arrowLeft} />

                            </View>
                        </TouchableOpacity>
                        <Text style={{ left: 40, fontFamily: APP_FONTS.bold }}>TOPWEAR</Text>
                    </View>
                    <View style={{ flexDirection: 'row' }}>
                        <Image source={APP_IMAGES.search} style={{ height: 20, width: 20, right: 30 }} resizeMode="contain" />
                        <Image source={APP_IMAGES.heart} style={{ height: 20, width: 20, right: 20 }} resizeMode="contain" />
                        <Image source={APP_IMAGES.cart} style={{ height: 20, width: 20, right: 10 }} resizeMode="contain" />
                    </View>


                </View>
                <ScrollView style={{ flex: 1, paddingBottom: 10 }}>
                    <View style={{ flex: 0.20, top: 10 }}>
                        <SliderBox
                            images={this.state.images}
                            sliderBoxHeight={500}
                            dotColor='#FD873B'
                        />
                        {/* <Image source={APP_IMAGES.productImage} style={{ height: 260, width: '100%' }} /> */}
                    </View>
                    <View style={{ padding: 20,   flex: 0.30 }}>
                        <Text style={{ fontSize: 15, color: 'black', top: 4, fontFamily: APP_FONTS.semi_bold }}>Chic Fuchsia Pink Power Shoulder Top</Text>
                        <Text style={{ fontSize: 15, color: 'black', fontFamily: APP_FONTS.bold, top: 8 }}>$20.00</Text>
                        <View style={{ flexDirection: 'row' ,padding:10,top:10}}>
                            {/* <View style={{ flexDirection: 'row',  borderWidth: 1, borderRadius: 20, borderEndWidth: 0, top: 0,right:20,  padding:5 }}> */}
                            <View style={{ flexDirection: 'row',borderColor:'#f0f0f0',borderWidth:1,padding:4,borderRadius:14}}>
                                <Image source={APP_IMAGES.commisionImage} style={{ height: 14, width: 14 }} />
                                <Text style={{ fontSize: 10, fontFamily: APP_FONTS.bold }}>$2 Commission    </Text>
                            </View>
                            <View style={{ flexDirection: 'row',borderColor:'#f0f0f0',borderWidth:1,padding:4,borderRadius:14,left:10}}>
                                {/* <Image source={APP_IMAGES.commisionImage} style={{ height: 14, width: 14 }} /> */}
                                <Text style={{ fontSize: 10, fontFamily: APP_FONTS.bold }}>  Free Delivery  </Text>
                            </View>
                        </View>
                    </View>
                    <View style={{ padding: 15,  borderWidth: 2, flex: 0.10,borderColor:'#f0f0f0',flexDirection:'row',justifyContent:'space-between'}}>
                        <Text style={{ fontSize: 16, fontFamily: APP_FONTS.bold, color: 'black' }}>Buy In Bulk</Text>
                        <Image source={APP_IMAGES.rightArrow} style={{height:10,width:10,top:5}}/>
                        {/* <Text>$20.00</Text> */}
                    </View>
                    <View style={{ padding: 15,  flex: 0.10 }}>

                        <Text style={{ fontSize: 16, fontFamily: APP_FONTS.bold, color: 'black' }}>Select Size</Text>
                        {/* <Text>$20.00</Text> */}
                    </View>
                    <View style={{ padding: 15, flex: 0.10, flexDirection: 'row' }}>
                        <View style={{ borderColor: '#fe6b8e', borderWidth: 1, borderRadius: 12, backgroundColor: '#ffedf1' }}>
                            <Text style={{ color: '#fe6b8e', fontSize: 12, fontFamily: APP_FONTS.bold, alignSelf: 'center' }}>   S   </Text>
                        </View>
                        <View style={{ borderColor: '#f0f0f0', borderWidth: 1, borderRadius: 14, backgroundColor: '#f9f9f9', left: 10 }}>
                            <Text style={{ color: '#777777', fontSize: 12, fontFamily: APP_FONTS.bold }}>  M  </Text>
                        </View>
                        <View style={{ borderColor: '#f0f0f0', borderWidth: 1, borderRadius: 14, backgroundColor: '#f9f9f9', left: 20 }}>
                            <Text style={{ color: '#777777', fontSize: 12, fontFamily: APP_FONTS.bold }}>  L  </Text>
                        </View>
                        <View style={{ borderColor: '#f0f0f0', borderWidth: 1, borderRadius: 14, backgroundColor: '#f9f9f9', left: 30 }}>
                            <Text style={{ color: '#777777', fontSize: 12, fontFamily: APP_FONTS.bold }}>  XL  </Text>
                        </View>
                        <View style={{ borderColor: '#f0f0f0', borderWidth: 1, borderRadius: 14, backgroundColor: '#f9f9f9', left: 40 }}>
                            <Text style={{ color: '#777777', fontSize: 12, fontFamily: APP_FONTS.bold }}>  XXL  </Text>
                        </View>
                    </View>
                    <View style={{ padding: 15,  borderWidth: 1, flex: 0.10 ,borderColor:'#f0f0f0'}}>
                        <Text style={{ fontSize: 16, fontFamily: APP_FONTS.bold, color: 'black' }}>Select Color</Text>
                        {/* <Text>$20.00</Text> */}
                    </View>
                    <View style={{ padding: 15, flexDirection: 'row', justifyContent: 'space-between'}}>
                        <Text style={{ fontSize: 16, fontFamily: APP_FONTS.bold, color: 'black' }}>Product Details</Text>
                        <Text style={{ color: '#fe668a', fontSize: 12, fontFamily: APP_FONTS.bold }}>Copy</Text>
                    </View>
                    <View style={{ padding: 15  }}>
                        <View style={{ flexDirection: 'row' }}>
                            <Text style={{ color: '#9a9a9a', fontFamily: APP_FONTS.semi_bold, fontSize: 12 }}>Care Instructions: </Text>
                            <Text style={{ color: 'black', fontFamily: APP_FONTS.semi_bold, fontSize: 12 }}>
                                Warm Hand Wash,Do Not Bleach
                            </Text>
                        </View>
                        <View style={{ flexDirection: 'row' }}>
                            <Text style={{ color: '#9a9a9a', fontFamily: APP_FONTS.semi_bold, fontSize: 12 }}>Fit Type: </Text>
                            <Text style={{ color: 'black', fontFamily: APP_FONTS.semi_bold, fontSize: 12 }}>Regular Fit</Text>
                        </View>
                        <View style={{ flexDirection: 'row' }}>
                            <Text style={{ color: '#9a9a9a', fontFamily: APP_FONTS.semi_bold, fontSize: 12 }}>Type:</Text>
                            <Text style={{ color: 'black', fontFamily: APP_FONTS.semi_bold, fontSize: 12 }}>Fuchsia pink halterneck swing Top</Text>
                        </View>



                    </View>
                    <View style={{ padding: 15,borderColor:'#f0f0f0',borderWidth:1}}>
                        <Text style={{ color: 'black', fontFamily: APP_FONTS.bold, fontSize: 16 }}>Similar Product</Text>
                        <View style={{ flex: 1, top: 20 }}>

                            <FlatList
                                horizontal
                                data={ITEMS}
                                style={{ flex: 1 }}
                                keyExtractor={item => item.id}
                                showsHorizontalScrollIndicator={false}
                                renderItem={({ item, index, separator }) => {
                                    return (

                                        <View style={{ marginLeft: 0, justifyContent: 'center', borderRadius: 6, alignItems: 'center', height: 284, width: 160 }}>
                                            <View style={{ height: 250, width: '98%', top: 46 }}>
                                                <Image source={item.category} style={{ width: '100%', height: 210 }} resizeMode='stretch' />
                                            </View>
                                            <View style={{ backgroundColor: 'white', bottom: 46, padding: 5, width: '98%', height: 90, borderBottomLeftRadius: 10, borderBottomRightRadius: 10 }}>
                                                <Text style={{ fontSize: 12, color: 'black', fontFamily: APP_FONTS.bold }}>Women Black and</Text>
                                                <Text style={{ fontSize: 12, color: 'black', fontFamily: APP_FONTS.bold }}>Pink Wrap Dress </Text>
                                                <Text style={{ color: '#F43297', fontSize: 13, fontFamily: APP_FONTS.bold }}>$20.00</Text>
                                                <View style={{ flexDirection: 'row' }}>
                                                    <Image source={APP_IMAGES.commisionImage} style={{ height: 14, width: 14 }} />
                                                    <Text style={{ fontSize: 10, fontFamily: APP_FONTS.bold }}>$2 Commission</Text>
                                                </View>
                                            </View>
                                        </View>
                                    )
                                }}
                            />
                        </View>
                    </View>
                    <View style={{borderWidth:1,borderColor:'#f0f0f0'}}>
                        <Text style={{ color: 'black', fontSize: 16, padding: 15, fontFamily: APP_FONTS.bold }}>Catlog Review</Text>

                    </View>
                    <View style={{ padding: 15 }}>
                        <Text style={{ color: 'black', fontSize: 12, fontFamily: APP_FONTS.semi_bold }}>Overall Rating</Text>
                        <Text style={{ color: 'black', fontSize: 26, fontFamily: APP_FONTS.bold }}>4.4</Text>


                    </View>
                    <View>
                        <Rating
                            // showRating
                            type='custom'
                            onFinishRating={this.ratingCompleted}
                            ratingColor='##d2d2d2'
                            tintColor='#34c759'
                            ratingBackgroundColor='#fffff'
                            imageSize={20}
                            style={{ alignSelf: 'flex-start', left: 20 }}
                        />
                    </View>
                    <View style={{ padding: 15 }}>
                        <Text style={{ color: 'black', fontSize: 12, fontFamily: APP_FONTS.bold }}>Customer Reviews</Text>
                        <FlatList
                            data={REVIEWS}
                            style={{ flex: 1, top: 10 }}
                            keyExtractor={item => item.id}
                            showsHorizontalScrollIndicator={false}
                            renderItem={({ item, index, separator }) => {
                                return (
                                    <View style={{ flex: 1 }}>
                                        <View style={{ flexDirection: 'row' }}>
                                            <Image source={item.profileImage} style={{ height: 24, width: 24 }} />
                                            <Text style={{ color: 'black', fontSize: 12, fontFamily: APP_FONTS.bold }}>  {item.profileName}</Text>
                                        </View>
                                        <View style={{ flexDirection: 'row', top: 6 }}>
                                            <View style={{ borderColor: '#7cc7c1', borderWidth: 1, borderRadius: 14, backgroundColor: '#e4f7f5' }}>
                                                <Text style={{ color: 'black', fontSize: 12 }}>  {item.rating} </Text>
                                            </View>
                                            <Text style={{ color: 'black', fontSize: 12, left: 10, fontFamily: APP_FONTS.semi_bold }}>{item.remark}</Text>
                                            <Text style={{ color: '#9d9d9d', fontSize: 10, fontFamily: APP_FONTS.bold, left: 15 }}> Posted on{item.date}</Text>
                                        </View>
                                        <View style={{ top: 10 }}>
                                            <View style={{ flexDirection: 'row' }}>
                                                <Image source={item.imageUpload} style={{ height: 40, width: 40 }} />
                                                <Image source={item.imageUpload} style={{ height: 40, width: 40, left: 10 }} />
                                                <Image source={item.imageUpload} style={{ height: 40, width: 40, left: 15 }} />
                                            </View>
                                            <Text style={{ color: 'black', fontSize: 12, fontFamily: APP_FONTS.semi_bold, top: 10, paddingBottom: 25 }}>{item.comment}</Text>
                                        </View>
                                        <View style={{borderWidth:1,borderColor:'#f0f0f0',bottom:2}} />
                                    </View>


                                )

                            }}
                        />
                    </View>
                </ScrollView>
                <View style={{ flex: 0.10, top: 10}}>
                <View style={{left:30,flexDirection:'row',top:30}}>
                        <Text style={{fontSize:10,color:'black',right:10,fontFamily:APP_FONTS.medium}}>Wishlist</Text>
                        <Text style={{fontSize:10,color:'black',right:5,fontFamily:APP_FONTS.medium}}>Share</Text>
                        <Text style={{fontSize:10,color:'black',fontFamily:APP_FONTS.medium}}>Download</Text>
                    </View>
                   
                  <View style={{flexDirection:'row',justifyContent:'space-between',bottom:10}}>  
                    <View style={{ flexDirection: 'row'}}>
                        <Image source={APP_IMAGES.heart} style={{ height: 16, width: 16, left: 30 }} resizeMode="contain" />
                        <Image source={APP_IMAGES.share} style={{ height: 16, width: 16, left: 55, tintColor: 'black' }} resizeMode="contain" />
                        <Image source={APP_IMAGES.downloadDark} style={{ height: 16, width: 16, left: 80 }} resizeMode="contain" />
                    </View>
                    {/* <View>
                        <Text>Wish</Text>
                    </View> */}
                    <View style={{ flexDirection: 'row', right: 20,  width: 150, height: 45, backgroundColor: '#F43297', borderRadius: 8, bottom: 10 }}>
                        <TouchableOpacity onPress={() => this.props.navigation.navigate('AddToBag')}>
                            <View style={{}}>
                                {/* <Image style={{ top: 0, left: 8, height: 20, width: 20, tintColor: 'black' }}
                                    resizeMode="contain"
                                    source={APP_IMAGES.arrowLeft} /> */}
                                <Image source={APP_IMAGES.cart} style={{ height: 20, width: 20, top: 12, left: 20, tintColor: 'white' }} resizeMode="contain" />
                                <Text style={{ fontFamily: APP_FONTS.bold, color: 'white', alignSelf: 'center', left: 50, bottom: 8 }}>Add to Bag</Text>

                            </View>
                        </TouchableOpacity>
                        {/* <Text style={{ left: 40, fontFamily: APP_FONTS.bold }}>TOPWEAR</Text> */}
                    </View>
                  
                    </View> 
                    <View style={{backgroundColor:'black'}}>
                        <Text style={{color:'black'}}>Wishlist</Text>

                    </View>
                  
                 {/* <View style={{backgroundColor:'red'}}>
                       <Text>Wishlist</Text> 
                 </View> */}
                </View>
            </SafeAreaView>
        )
    }



}

export default productDetail;