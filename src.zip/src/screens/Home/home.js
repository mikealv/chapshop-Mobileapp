import React, { Component } from "react";
import { Image, SafeAreaView, Text, View, TextInput, TouchableOpacity, FlatList, ImageBackground, Modal, Platform, ScrollView, StatusBar, KeyboardAvoidingView } from "react-native";
import { APP_IMAGES, APP_FONTS, BUTTON, APP_URLS } from "../../utils/Common";
import DatePicker from 'react-native-date-picker';
 import CountryPicker from 'react-native-country-picker-modal';
import AppStyle from '../../style/AppStyle'
import AsyncStorage from '@react-native-async-storage/async-storage';

// import axios from 'react-native-axios';

const CATEGORY = [
    {
        id: 1,
        category: require('../../../assets/images/image-one.png'),
        name: 'Tops'
    },
    {
        id: 2,
        category: require('../../../assets/images/image-two.png'),
        name: 'Tshirts'
    },
    {
        id: 3,
        category: require('../../../assets/images/image-three.png'),
        name: 'Jackets',

    },
    {
        id: 4,
        category: require('../../../assets/images/image-four.png'),
        name: 'Jackets'
    },
    {
        id: 5,
        category: require('../../../assets/images/image-one.png'),
        name: 'Tops'
    },
    {
        id: 6,
        category: require('../../../assets/images/image-two.png'),
        name: 'Jackets'
    }
]

const ITEMS = [
    {
        id: 1,
        category: require('../../../assets/images/product-img.png'),
        name: 'Tops'
    },
    {
        id: 2,
        category: require('../../../assets/images/product-img.png'),
        name: 'Tshirts'
    },
    {
        id: 3,
        category: require('../../../assets/images/product-img.png'),
        name: 'Jackets',

    },
    {
        id: 4,
        category: require('../../../assets/images/product-img.png'),
        name: 'Jackets'
    },
    {
        id: 5,
        category: require('../../../assets/images/product-img.png'),
        name: 'Tops'
    },
    {
        id: 6,
        category: require('../../../assets/images/product-img.png'),
        name: 'Jackets'
    }
]

const createFormData = (image) => {
    var data = new FormData();
    data.append('upload', {
        uri: Platform.OS === "android" ? image : image.replace("file://", ""),
        name: `chapShop${Date.now()}.jpg`,
        type: 'image/*'
    })
    return data
}


class home extends Component {

    constructor(props) {
        super(props)
        this.state = {
            modalVisible: true,
            // date: '',
            setOpen: true,
            // mCountryCode: '91',
            countryCode: '+91',
            iso: 'IN',
            cca2: 'IN',
            open: true,
            date: new Date(),
            showActiveMen: false,
            showActiveWomen: false,
            phone: '',
            gender: '',
            token: ''

        }
    }

    async userDetail() {
        console.log('userDetail===>')
        // let token = ''

        let userS = await AsyncStorage.getItem('@userToken')
        console.log(userS, 'userssss')
        //    let shahank =JSON.parse(JSON.stringify(userS))
        // JSON.stringify(userS))
        // console.log('convooo3sWW', JSON.parse(userS))
        // console.log(userS.accessToken\,'hdbjdsdjsdbjsdb')
        //console.log(userS[0]._id,'userS-xx--->')
        // alert(userS)
        // })
        this.setState({
            token: userS
        }, () => { this.state.token, 'token--->' })

        // await AsyncStorage.getItem('@user',JSON.stringify(user)).then(() => {
        //     console.log(user, 'fcmtokenLoginß')

        // })
    }

    date() {
        this.setState({
            date: ''
        })
    }
    closeModal() {
        console.log('bababa')
        this.setState({
            modalVisible: false
        })
    }
    open() {
        this.setState({
            setOpen: true
        })
    }


    componentDidMount() {
        this.userDetail()
    }

    setModalVisible() {
        this.setState({
            modalVisible: true
        })
    }

    _selectedValue(index) {
        this.setState({
            mCountryCode: index
        })

    }

    dateSet() {
        this.setState({
            date: ''
        })
    }

    //     async submit() {

    //         let formData = new FormData()
    //         formData.append("dateOfBirth", this.state.date.toLocaleDateString())
    //         formData.append("gender", this.state.gender)
    //         formData.append("moneyPhoneNumber", this.state.countryCode + this.state.phone)
    //         // console.log(this.state.token, 'tokeeen--{{}}  ')
    //         // console.log(formData, 'formData-->')
    //         // try {




    // let Authorization = 'Bearer '+this.state.token 

    // console.log(Authorization,"Authorization====")

    //         const res = await axios({
    //             method: 'PUT',
    //             url: APP_URLS.editAccount,
    //             data: formData,
    //             headers: {
    //                 headers: { "Content-Type": "multipart/form-data" },
    //                 Authorization: this.state.to
    //             },
    //         });

    //         console.log(res, "axios res",)
    //         //             let response = await fetch(

    //         //                 APP_URLS.editAccount,
    //         //                 {
    //         //                     'method': 'PUT',
    //         //                     headers: {
    //         //                         // 'Accept': 'application/json',
    //         //                         // 'Content-Type': 'application/json',
    //         //                         'Content-Type': 'multipart/form-data',
    //         //                         // 'Authorization': 'Bearer'+this.state.token
    //         //                         'Authorization': "Bearer"+'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2MjRjMGMyOWMzYmM2MzJkZjJjYTYxMGEiLCJpYXQiOjE2NTEyMTY1NTJ9.QdAbzE1bqe5zvU2WVJ1CHTaTapQDJR6KdGJP_wfmneY'
    //         // // '                        // 'Authorization':'Bearer'+'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2MjRkMjQ5ZmQwZTcyNTNiYzdlOTAwMjAiLCJpYXQiOjE2NTExNDY1MDF9.f82KLM35P4M3nzs_8Kf-cHHD8Nv9uUQCGGO_Dsc6oQY'
    //         //                         // 'Authorization':'Bearer'+'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2MjRkMjQ5ZmQwZTcyNTNiYzdlOTAwMjAiLCJpYXQiOjE2NTExNDU0Mjl9.-GmIfeVGjgtlvTMoX9qGiI848zWRETDo78U5nRfpD_A'
    //         //                     },
    //         //                     // body: createFormData(body)
    //         //                     data: formData

    //         //                 }

    //         //             );



    //         //             if (response.status == 200) {



    //         //                 console.log('normal')

    //         //                 response.json().then(data => {

    //         //                     console.log('convooo3shomomoe', JSON.stringify(data))
    //         //                     //console.log('convoeys', JSON.stringify(data.usersChatData[0].message))
    //         //                     // if (data.response.status.statusCode === 200) {
    //         //                     if (data.status === 1) {
    //         //                         // this.setState({
    //         //                         //     otpRecieved: data.message
    //         //                         // })
    //         //                         alert('Details Submitted')
    //         //                         // let token = data.response.userData.accessToken
    //         //                         // let user = data.response.userData
    //         //                         // userToken = token
    //         //                         // AsyncStorage.setItem('@user', JSON.stringify(user)).then(() => {
    //         //                         //     this.props.navigation.navigate('DrawerScreen')
    //         //                         //     this.setState({
    //         //                         //         isLoading:false
    //         //                         //     })
    //         //                         // })
    //         //                         // this.props.navigation.navigate('Otp', {
    //         //                         //     otpOutput: this.state.otpRecieved,
    //         //                         //     phoneNumber: this.state.phone,
    //         //                         //     countryCode: this.state.countryCode
    //         //                         // })
    //         //                         // alert('hahaah')
    //         //                     }
    //         //                     else if (data.status === 0) {
    //         //                         alert(data.message)
    //         //                         // alert('luliya')
    //         //                         // console.log(body, 'boddy-edit123->   ' + APP_URLS.editAccount)

    //         //                         console.log(this.state.token, "this.state.token")
    //         //                     }
    //         //                     else {
    //         //                         this.setState({ isLoading: false }, () => {
    //         //                         })
    //         //                     }

    //         //                 });
    //         //             } else {

    //         //                 this.setState({ isLoading: false }, () => {

    //         //                     alert('Something went wrong error code: ' + response.status)
    //         //                 })
    //         //             }

    //         // }
    //         // catch (error) {

    //         //     this.setState({ isLoading: false }, () => {
    //         //         alert('Something went wrong error code: ' + error)
    //         //     })
    //         // }
    //     }

    submit() {
        alert('Your Details have been submited')
        this.setState({
            modalVisible: false
        })
    }
    submitQ(){
        // alert('Your Details have been submited')
        this.setState({
            modalVisible: false
        })
    }

    // submit(){
    //     // alert('Details Submitted')
    //     this.setState({
    //         modalVisible:false
    //     })
    // }

    activeGender() {
        this.setState({
            showActiveMen: true,
            showActiveWomen: false,
            gender: 'male'
        })
    }
    activeWomenGender() {
        this.setState({
            showActiveWomen: true,
            showActiveMen: false,
            gender: 'female'

        })
    }


    womenClothView(item) {
        return (

            <View style={{ marginLeft: 0, justifyContent: 'center', borderRadius: 6, alignItems: 'center', height: 284, width: 160 }}>
                <View style={{ height: 280, width: '98%', top: 46 }}>
                    <Image source={item.category} style={{ width: '100%', height: 210 }} resizeMode='stretch' />
                </View>
                <View style={{ backgroundColor: 'white', bottom: 46, padding: 5, width: '98%', height: 90, borderBottomLeftRadius: 10, borderBottomRightRadius: 10 }}>
                    <Text style={{ fontSize: 12, color: 'black', fontFamily: APP_FONTS.bold }}>Women Black and</Text>
                    <Text style={{ fontSize: 12, color: 'black', fontFamily: APP_FONTS.bold }}>Pink Wrap Dress </Text>
                    <Text style={{ color: '#F43297', fontSize: 13, fontFamily: APP_FONTS.bold }}>$20.00</Text>
                    <View style={{ flexDirection: 'row' }}>
                        <Image source={APP_IMAGES.commisionImage} style={{ height: 14, width: 14 }} />
                        <Text style={{ fontSize: 10, fontFamily: APP_FONTS.bold }}>$2 Commission</Text>
                    </View>
                </View>
            </View>
        )

    }

    render() {
        const { date } = this.state;
        return (
            <SafeAreaView style={{ flex: 1 }}>
                <StatusBar
                    backgroundColor="white"
                    barStyle={"dark-content"}
                    showHideTransition={"none"}
                    hidden={false} />

                <ScrollView >
                    <View style={{ flex: 1, paddingBottom: 80 }}>
                        <View style={{ padding: 10, flexDirection: 'row', justifyContent: 'space-between' }}>
                            <View style={{ flexDirection: 'row' }}>
                                <Image source={APP_IMAGES.profileImage} style={{ height: 40, width: 40, left: 7, bottom: 3 }} />
                                <Text style={{ left: 20, top: 3, color: 'black', fontFamily: APP_FONTS.bold }}>Jennifer Smith</Text>
                            </View>
                            <View style={{ flexDirection: 'row' }}>
                                <Image source={APP_IMAGES.bell} style={{ height: 30, width: 15, right: 25 }} resizeMode={'contain'} />
                                <Image source={APP_IMAGES.cart} style={{ height: 30, width: 15, right: 5 }} resizeMode={'contain'} />
                            </View>
                        </View>
                        <View style={{ flexDirection: 'row', top: 20, right: 10 }}>
                            <Image source={APP_IMAGES.search} style={{ height: 20, width: 20, top: 10, left: 40, zIndex: 100 }} resizeMode='contain' />
                            <TextInput ref={input => { this.textInput = input }}
                                style={{
                                    width: '92%',
                                    height: 45,
                                    fontSize: 13,
                                    fontFamily: APP_FONTS.medium,
                                    borderRadius: 5,
                                    alignSelf: 'center',
                                    color: 'black',
                                    //fontWeight:'400',
                                    borderColor: '#D6D6D6',
                                    borderWidth: 1,
                                    backgroundColor: 'white',
                                    // left:30,
                                    // left: 6,
                                    padding: 10,
                                    textAlign: 'center'
                                }}
                                placeholder="Search by Keyboard or Product ID"
                                keyboardType="default"
                                placeholderTextColor={'#A0A0A0'}
                                onChangeText={this.handlesearchText}>
                            </TextInput>
                        </View>
                        <View style={{ flex: 1, width: '100%', left: 10, top: 30 }}>
                            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                                <View style={{ left: 2 }}>
                                    <Text style={{ fontFamily: APP_FONTS.bold, fontSize: 13, color: 'black', padding: 10 }}>Best Sellers</Text>
                                </View>
                                <View style={{ right: 20 }}>
                                    <Text style={{ fontFamily: APP_FONTS.bold, fontSize: 12, color: '#F43297', padding: 10 }}>View All</Text>
                                </View>
                            </View>
                            <View style={{ justifyContent: 'space-between', top: 10 }}>
                                <FlatList
                                    horizontal
                                    data={CATEGORY}
                                    style={{ flex: 1 }}
                                    keyExtractor={item => item.id}
                                    showsHorizontalScrollIndicator={false}
                                    renderItem={({ item, index, separator }) => {

                                        let bg = ''
                                        if (item.name == 'Chinese') {
                                            bg = '#CAE9F6'
                                        }
                                        if (item.name == 'American') {
                                            bg = '#CAF7D5'
                                        }
                                        if (item.name == 'Indian') {
                                            bg = '#F7CFC9'
                                        }
                                        if (item.name == 'Italian') {
                                            bg = '#CCCAF1'
                                        }
                                        return (


                                            <View style={{ marginLeft: 10, justifyContent: 'center', borderRadius: 6, alignItems: 'center' }}>
                                                <View style={{ width: 70, height: 70, borderRadius: 35, justifyContent: 'center', alignItems: 'center' }}>
                                                    <Image source={item.category} style={{ height: 70, width: 70, right: 0 }} resizeMode='contain' />
                                                </View>
                                                <View>
                                                    <Text style={{ fontSize: 11, fontFamily: APP_FONTS.semi_bold }}>{item.name}</Text>
                                                </View>
                                            </View>



                                        )
                                    }}
                                />
                            </View>

                            <View style={{ top: 40, flex: 1 }}>
                                <ImageBackground source={APP_IMAGES.patternBackground} style={{ height: '180%', width: '100%', right: 10 }}>

                                    <View style={{ padding: 20, flex: 1 }}>
                                        <Text style={{ fontFamily: APP_FONTS.regular, fontSize: 12 }} >BEST SELLERS</Text>
                                        <Text style={{ fontFamily: APP_FONTS.bold, fontSize: 16 }} >PRODUCTS TO SHARE TODAY</Text>
                                        <Text style={{}}>Loreum ipsum dolor sit amet,consectetur adipiscing elit,</Text>
                                        <Text style={{}}>sed do elusmod tempor incididunt</Text>
                                        <View style={{ top: 10 }}>
                                            <TouchableOpacity onPress={() => this.login()} style={{
                                                width: "30%", height: 30,
                                                backgroundColor: '#F43297',
                                                borderRadius: 5,
                                                justifyContent: "center",
                                                alignItems: "center",
                                                flexDirection: 'row'
                                            }}>
                                                <Image source={APP_IMAGES.share} style={{ height: 15, width: 15, right: 6 }} resizeMode="contain" />
                                                <Text style={{ color: "white", fontFamily: APP_FONTS.bold, fontSize: 12 }}>
                                                    Share All
                                                </Text>
                                            </TouchableOpacity>

                                        </View>
                                        <View style={{ flex: 1, top: 20 }}>

                                            <FlatList
                                                horizontal
                                                data={ITEMS}
                                                style={{ flex: 1 }}
                                                keyExtractor={item => item.id}
                                                showsHorizontalScrollIndicator={false}
                                                renderItem={({ item, index, separator }) => {
                                                    return (

                                                        <View style={{ marginLeft: 0, justifyContent: 'center', borderRadius: 6, alignItems: 'center', height: 284, width: 160 }}>
                                                            <View style={{ height: 250, width: '98%', top: 46 }}>
                                                                <Image source={item.category} style={{ width: '100%', height: 210 }} resizeMode='stretch' />
                                                            </View>
                                                            <View style={{ backgroundColor: 'white', bottom: 46, padding: 5, width: '98%', height: 90, borderBottomLeftRadius: 10, borderBottomRightRadius: 10 }}>
                                                                <Text style={{ fontSize: 12, color: 'black', fontFamily: APP_FONTS.bold }}>Women Black and</Text>
                                                                <Text style={{ fontSize: 12, color: 'black', fontFamily: APP_FONTS.bold }}>Pink Wrap Dress </Text>
                                                                <Text style={{ color: '#F43297', fontSize: 13, fontFamily: APP_FONTS.bold }}>$20.00</Text>
                                                                <View style={{ flexDirection: 'row' }}>
                                                                    <Image source={APP_IMAGES.commisionImage} style={{ height: 14, width: 14 }} />
                                                                    <Text style={{ fontSize: 10, fontFamily: APP_FONTS.bold }}>$2 Commission</Text>
                                                                </View>
                                                            </View>
                                                        </View>
                                                    )
                                                }}
                                            />
                                        </View>
                                    </View>
                                    <View>

                                    </View>
                                </ImageBackground>
                            </View>

                        </View>
                        <Modal
                            animationType="slide"
                            transparent={true}
                            visible={this.state.modalVisible}
                            onRequestClose={() => {
                                this.setModalVisible(!this.state.modalVisible);
                            }}
                        >
                            {/* <ScrollView contentContainerStyle={{flexGrow:1}}  keyboardShouldPersistTaps='always'> */}
                            {/* <ScrollView contentContainerStyle={{ flexGrow: 1 }}> */}
                            <KeyboardAvoidingView behavior='position' enabled>

                                <View style={{
                                    backgroundColor: "white",
                                    // backgroundColor: "red",
                                    borderRadius: 20,
                                    height: Platform.OS === "android" ? 600 : 600,
                                    width: '88%',

                                    shadowColor: "#000",
                                    shadowOffset: {
                                        width: 0,
                                        height: 2
                                    },
                                    shadowOpacity: 0.25,
                                    shadowRadius: 4,
                                    elevation: 5,
                                    left: 23,
                                    top: Platform.OS == "android" ? 70 : 30,
                                    // borderColor:'black',
                                    // borderWidth:1

                                }}>


                                    <View style={{ backgroundColor: '#BCC7FF', width: '100%', height: 250, justifyContent: 'center', borderTopLeftRadius: 10, borderTopRightRadius: 10 }}>

                                    </View>


                                    <View style={{ bottom: Platform.OS === 'android' ? 110 : 110, borderTopRightRadius: 100, borderTopLeftRadius: 100, height: Platform.OS == 'android' ? 360 : 400, width: '100%', right: 0, backgroundColor: 'white' }}>

                                        <View style={{ justifyContent: 'center', alignItems: 'center', bottom:Platform.OS == 'ios'? 130:160 }}>
                                            <Image source={APP_IMAGES.popVector} style={{ height: 150, width: '100%', zIndex: 100, top: Platform.OS == "android" ? 30 : 0, bottom: Platform.OS == "ios" ? 0 : 0 }} resizeMode='contain' />
                                        </View>

                                        <View style={{ top: Platform.OS == 'android' ? -160 : -120, bottom: Platform.OS == 'ios' ? 200 : 0 }}>
                                            <Text style={{ alignSelf: 'center', fontFamily: APP_FONTS.medium, fontSize: 14, color: 'black', top: Platform.OS === 'android' ? 45 : 0 }}>Select your gender</Text>
                                        </View>
                                        {/* <View style={{ bottom: Platform.OS === 'android' ? 123 : 115, borderTopRightRadius: 100, borderTopLeftRadius: 100, height: Platform.OS == 'android' ? 320 : 440, width: '100%', backgroundColor: 'white', right: 0, borderWidth: 1, borderColor: 'black' }}>

                                        <View style={{ justifyContent: 'center', top: Platform.OS == 'android' ? 10 : 30, borderColor: 'red', borderWidth: 1 }}>
                                            <Text style={{ alignSelf: 'center', fontFamily: APP_FONTS.medium, fontSize: 14, color: 'black', top: Platform.OS === 'android' ? 45 : 0 }}>Select your gender</Text>

                                        </View> */}
                                        <View style={{ flexDirection: 'row', top: Platform.OS == 'android' ? -110 : -110, flex: 1, justifyContent: 'space-around' }}>
                                            {this.state.showActiveMen == false ?
                                                <View style={{ borderColor: '#e9e8e9', borderWidth: 1, width: 60, height: 60, borderRadius: 30, left: 30 }}>
                                                    <TouchableOpacity onPress={() => { this.activeGender() }}>
                                                        <Image source={APP_IMAGES.manGender} style={{ height: 40, width: 40, right: 0, alignSelf: 'center', resizeMode: 'contain', top: 10 }} />
                                                    </TouchableOpacity>
                                                </View>
                                                :
                                                <View style={{ borderColor: '#F43297', borderWidth: 1, width: 60, height: 60, borderRadius: 30, left: 30 }}>
                                                    <Image source={APP_IMAGES.manGender} style={{ height: 40, width: 40, right: 0, alignSelf: 'center', resizeMode: 'contain', top: 10 }} />
                                                </View>
                                            }
                                            <View style={{ height: 50, width: 50 }}>
                                                <Text style={{ fontSize: 17, color: '#b4b5b5', alignSelf: 'center', top: 10 }}>or</Text>
                                            </View>
                                            {this.state.showActiveWomen == false ?
                                                <View style={{ borderColor: '#e9e8e9', borderWidth: 1, right: 0, width: 60, height: 60, borderRadius: 30, right: 30 }}>
                                                    <TouchableOpacity onPress={() => { this.activeWomenGender() }}>
                                                        <Image source={APP_IMAGES.women} style={{ height: 40, width: 40, left: 0, alignSelf: 'center', top: 10, resizeMode: 'contain' }} />
                                                    </TouchableOpacity>
                                                </View>
                                                :
                                                <View style={{ borderColor: '#F43297', borderWidth: 1, right: 0, width: 60, height: 60, borderRadius: 30, right: 30 }}>
                                                    <Image source={APP_IMAGES.women} style={{ height: 40, width: 40, left: 0, alignSelf: 'center', top: 10, resizeMode: 'contain' }} />
                                                </View>
                                            }
                                        </View>
                                        <View style={{ top: Platform.OS == 'android' ? -40 : -40, justifyContent: 'center', alignItems: 'center' }}>
                                            <Text style={{ color: 'black', fontFamily: APP_FONTS.medium, fontSize: 14 }}>Enter Your Age </Text>

                                            <DatePicker
                                                date={this.state.date}
                                                mode="date"
                                                format="YYYY/MM/DD"
                                                style={{ width: Platform.OS == 'android' ? 230 : 230, height: Platform.OS == 'android' ? 70 : 130, top: Platform.OS == "android" ? 20 : 0 }}
                                                maxDate={new Date("2022-05-05")}
                                                onDateChange={(date) => { this.setState({ date: date }) }}

                                            />
                                        </View>
                                        <View style={{ top: Platform.OS == 'android' ? 10 : -40, alignItems: 'center', height: Platform.OS == 'ios' ? 120 : 120 }}>
                                            <Text style={{ color: 'black', fontSize: 14, fontFamily: APP_FONTS.medium }}>Mobile Money Number</Text>
                                            <View style={{ flexDirection: 'row', borderRadius: 5, top: Platform.OS === 'ios' ? 8 : 10 ,
                                              borderWidth:1,borderColor:'#ececec'
                                        }}>
                                                <CountryPicker
                                                    countryCode={this.state.cca2}
                                                    containerButtonStyle={{
                                                        marginRight:Platform.OS == 'ios'? 8:8,
                                                        padding:Platform.OS == 'ios'? 6:6,
                                                        // borderColor:'red',
                                                        // borderWidth:1,
                                                        // paddingTop:20
                                                                             

                                                    }}
                                                    withFlag
                                                    withModal
                                                    withCallingCode
                                                    withAlphaFilter
                                                    withFilter
                                                    withCallingCodeButton
                                                    onSelect={(country) => this.setState({ cca2: country.cca2, countryCode: '+' + country.callingCode, iso: country.cca2 })}

                                                >
                                                </CountryPicker>
                                                <View style={{ borderWidth: 1, borderColor: '#e9e8e9', height: 24, justifyContent: 'center', alignSelf: 'center' }} />
                                                <TextInput
                                                    style={{
                                                        height: 35,
                                                        width: '68%',
                                                        alignSelf: 'center',
                                                        paddingHorizontal: 20,
                                                        borderRadius: 8
                                                    }}

                                                    placeholder="Phone Number"
                                                    keyboardType="numeric"
                                                    ref={(rf) => { this.phone = rf }}
                                                    value={this.state.phone}
                                                    onChangeText={(text) => this.setState({ phone: text })}
                                                />
                                            </View>


                                            {/* <TouchableOpacity onPress={() => {this.closeModal()}}>
                                            <View style={{ top: 10 }}>
                                               
                                                    <Text style={{ color: "#F43297", fontFamily: APP_FONTS.bold, fontSize: 14 }}>
                                                        Set up Later
                                                    </Text>
                                            </View>
                                            </TouchableOpacity> */}
                                            {/* <View style={{ marginLeft: 20, marginRight: 20, bottom: 40 ,width:'80%',borderWidth:1,borderColor:'blue'}}>
                                                <TouchableOpacity onPress={() => this.submit()} style={{
                                                    width: "100%", height: 50,
                                                    backgroundColor: '#F43297',
                                                    borderRadius: 10,
                                                    justifyContent: "center",
                                                    alignItems: "center",
                                                    marginTop: 60
                                                }}>
                                                     <Text style={{ color: "white", fontFamily: APP_FONTS.bold, fontSize: 18 }}>
                                                        Submit
                                                    </Text>
                                                    
                                                </TouchableOpacity>
                                            </View> */}
                                            {/* <TouchableOpacity onPress={() => this.login()} style={[BUTTON, { marginTop: 60 }]}> */}
                                            {/* <TouchableOpacity onPress={() => this.props.navigation.navigate('Otp')} style={[BUTTON, { marginTop: 70 }]}> */}
                                            {/* <TouchableOpacity onPress={() => { this.closeModal() }} style={{borderColor:'red',borderWidth:1,bottom:30}}>
                                            <View style={{ bottom: 0 }}>
                                                    <Text style={{ color: "#F43297", fontFamily: APP_FONTS.bold, fontSize: 14 }}>
                                                        Set up Later
                                                    </Text>
                                            </View>
                                            </TouchableOpacity> */}

                                            {/* <Button> */}


                                            {/* </Button> */}
                                            {/* </TouchableOpacity> */}

                                            {/* </View> */}


                                        </View>
                                        <View style={{ marginLeft: 20, marginRight: 20 }}>
                                            <TouchableOpacity onPress={() => this.submit()} style={[BUTTON, { marginTop:Platform.OS == 'ios'?  -70:-10 }]}>
                                                {/* <TouchableOpacity onPress={() => this.props.navigation.navigate('Otp')} style={[BUTTON, { marginTop: 70 }]}> */}
                                                <Text style={{ color: "white", fontFamily: APP_FONTS.bold, fontSize: 18 }}>
                                                    Submit
                                                </Text>
                                                {/* <Button> */}



                                                {/* </Button> */}
                                            </TouchableOpacity>
                                            
                                        </View>
                                        <View style={{marginTop:Platform.OS == 'ios'? -10:10}}> 
                                        <TouchableOpacity onPress={()=>this.submitQ()} >
                                                <Text style={{ color: "#F43297", fontFamily: APP_FONTS.bold, fontSize: 14 ,alignSelf:'center'}}>
                                                    Set Up Later
                                                </Text>
                                            </TouchableOpacity>

                                        </View>
                                        {/* <View style={{ marginLeft:20,marginRight:20 }}> */}
                                        {/* <TouchableOpacity onPress={() => this.submit()} style={[BUTTON, { marginTop: -90 }]}>
                                                {/* <TouchableOpacity onPress={() => this.props.navigation.navigate('Otp')} style={[BUTTON, { marginTop: 70 }]}> */}
                                        {/* <Text style={{ color: "white", fontFamily: APP_FONTS.bold, fontSize: 18 }}>
                                                    Set Up Later
                                                </Text> */}
                                        {/* <Button> */}


                                        {/* </Button> */}
                                        {/* </TouchableOpacity> */}

                                        {/* </View> */}


                                        {/* <Text onPress={() => this.closeModal()} style={{ top: 40 }}>Submit</Text> */}



                                    </View>
                                </View>
                            {/* </ScrollView> */}
                            </KeyboardAvoidingView>

                        </Modal>
                    </View>
                </ScrollView>
            </SafeAreaView>
        )
    }



}
// const styles = StyleSheet.create({

//     pickerStyle: {
//         height: 20,
//         width: 250,
//         marginBottom: 10,
//         justifyContent: 'center',
//         padding: 10,
//         borderWidth: 2,
//         borderColor: '#303030',
//         backgroundColor: 'white',
//     },
//     selectedCountryTextStyle: {
//         paddingLeft: 5,
//         paddingRight: 5,
//         color: '#000',
//         textAlign: 'right',
//     },
//     pickerStyle: {

//     }

// })

export default home;