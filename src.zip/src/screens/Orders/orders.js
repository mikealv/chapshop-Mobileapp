
import React,{ Component } from "react";
import {Text} from "react-native";
import { APP_FONTS } from "../../utils/Common";





class orders extends Component {

      constructor(props){
          super(props)
          this.state={

          }
      }

      render(){
          return(
            <Text style={{fontSize:20,alignSelf:'center',fontFamily:APP_FONTS.bold}}>Pending</Text>
          )
      }

      

}

export default orders;